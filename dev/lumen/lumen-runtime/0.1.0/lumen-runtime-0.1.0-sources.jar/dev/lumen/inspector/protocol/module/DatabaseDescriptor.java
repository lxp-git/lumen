/*
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

package dev.lumen.inspector.protocol.module;

public interface DatabaseDescriptor {
  /**
   * The user visible name for this database.
   */
  String name();
}
