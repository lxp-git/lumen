/*
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

package dev.lumen.inspector.elements.android;

import android.graphics.Rect;
import android.view.View;

import dev.lumen.common.Accumulator;
import dev.lumen.common.LogUtil;
import dev.lumen.common.android.FragmentAccessor;
import dev.lumen.common.android.FragmentCompat;
import dev.lumen.common.android.ResourcesUtil;
import dev.lumen.inspector.elements.AttributeAccumulator;
import dev.lumen.inspector.elements.AbstractChainedDescriptor;
import dev.lumen.inspector.elements.Descriptor;
import dev.lumen.inspector.elements.DescriptorMap;

import javax.annotation.Nullable;

final class FragmentDescriptor
    extends AbstractChainedDescriptor<Object> implements HighlightableDescriptor<Object> {
  private static final String ID_ATTRIBUTE_NAME = "id";
  private static final String TAG_ATTRIBUTE_NAME = "tag";

  private final FragmentAccessor mAccessor;

  public static DescriptorMap register(DescriptorMap map) {
    maybeRegister(map, FragmentCompat.getSupportLibInstance());
    maybeRegister(map, FragmentCompat.getFrameworkInstance());
    return map;
  }

  private static void maybeRegister(DescriptorMap map, @Nullable FragmentCompat compat) {
    if (compat != null) {
      Class<?> fragmentClass = compat.getFragmentClass();
      LogUtil.d("Adding support for %s", fragmentClass.getName());
      map.registerDescriptor(fragmentClass, new FragmentDescriptor(compat));
    }
  }

  private FragmentDescriptor(FragmentCompat compat) {
    mAccessor = compat.forFragment();
  }

  @Override
  protected void onGetAttributes(Object element, AttributeAccumulator attributes) {
    int id = mAccessor.getId(element);
    if (id != FragmentAccessor.NO_ID) {
      String value = ResourcesUtil.getIdStringQuietly(
          element,
          mAccessor.getResources(element),
          id);
      attributes.store(ID_ATTRIBUTE_NAME, value);
    }

    String tag = mAccessor.getTag(element);
    if (tag != null && tag.length() > 0) {
      attributes.store(TAG_ATTRIBUTE_NAME, tag);
    }
  }

  @Override
  protected void onGetChildren(Object element, Accumulator<Object> children) {
    View view = mAccessor.getView(element);
    if (view != null) {
      children.store(view);
    }
  }

  @Override
  @Nullable
  public View getViewAndBoundsForHighlighting(Object element, Rect bounds) {
    return mAccessor.getView(element);
  }

  @Nullable
  @Override
  public Object getElementToHighlightAtPosition(Object element, int x, int y, Rect bounds) {
    final Descriptor.Host host = getHost();
    View view = null;
    HighlightableDescriptor descriptor = null;

    if (host instanceof AndroidDescriptorHost) {
      view = mAccessor.getView(element);
      descriptor = ((AndroidDescriptorHost) host).getHighlightableDescriptor(view);
    }

    return descriptor == null
        ? null
        : descriptor.getElementToHighlightAtPosition(view, x, y, bounds);
  }
}
