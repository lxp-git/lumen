/*
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

package dev.lumen.inspector.elements.android;

import android.app.Dialog;
import android.graphics.Rect;
import android.view.View;
import android.view.Window;
import dev.lumen.common.Accumulator;
import dev.lumen.inspector.elements.AbstractChainedDescriptor;
import dev.lumen.inspector.elements.Descriptor;

import javax.annotation.Nullable;

final class DialogDescriptor
    extends AbstractChainedDescriptor<Dialog> implements HighlightableDescriptor<Dialog> {
  @Override
  protected void onGetChildren(Dialog element, Accumulator<Object> children) {
    Window window = element.getWindow();
    if (window != null) {
      children.store(window);
    }
  }

  @Nullable
  @Override
  public View getViewAndBoundsForHighlighting(Dialog element, Rect bounds) {
    final Descriptor.Host host = getHost();
    Window window = null;
    HighlightableDescriptor descriptor = null;

    if (host instanceof AndroidDescriptorHost) {
      window = element.getWindow();
      descriptor = ((AndroidDescriptorHost) host).getHighlightableDescriptor(window);
    }

    return descriptor == null
        ? null
        : descriptor.getViewAndBoundsForHighlighting(window, bounds);
  }

  @Nullable
  @Override
  public Object getElementToHighlightAtPosition(Dialog element, int x, int y, Rect bounds) {
    final Descriptor.Host host = getHost();
    Window window = null;
    HighlightableDescriptor descriptor = null;

    if (host instanceof AndroidDescriptorHost) {
      window = element.getWindow();
      descriptor = ((AndroidDescriptorHost) host).getHighlightableDescriptor(window);
    }

    return descriptor == null
        ? null
        : descriptor.getElementToHighlightAtPosition(window, x, y, bounds);
  }
}
