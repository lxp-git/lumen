/*
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

package dev.lumen.inspector.console;

import dev.lumen.common.LogRedirector;
import dev.lumen.inspector.helper.ChromePeerManager;
import dev.lumen.inspector.protocol.module.Console;

import javax.annotation.Nonnull;

/**
 * Utility for reporting an event to the console
 */
public class CLog {
  private static final String TAG = "CLog";

  public static void writeToConsole(
      ChromePeerManager chromePeerManager,
      Console.MessageLevel logLevel,
      Console.MessageSource messageSource,
      String messageText) {
    // Send to logcat to increase the chances that a developer will notice :)
    LogRedirector.d(TAG, messageText);

    Console.ConsoleMessage message = new Console.ConsoleMessage();
    message.source = messageSource;
    message.level = logLevel;
    message.text = messageText;
    Console.MessageAddedRequest messageAddedRequest = new Console.MessageAddedRequest();
    messageAddedRequest.message = message;
    chromePeerManager.sendNotificationToPeers("Console.messageAdded", messageAddedRequest);
  }

  public static void writeToConsole(
      Console.MessageLevel logLevel,
      Console.MessageSource messageSource,
      String messageText
  ) {
    ConsolePeerManager peerManager = ConsolePeerManager.getInstanceOrNull();
    if (peerManager == null) {
      return;
    }

    writeToConsole(peerManager, logLevel, messageSource, messageText);
  }
}
