/*
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

package dev.lumen.inspector.database;

import android.database.sqlite.SQLiteException;

import dev.lumen.inspector.protocol.module.Database;
import dev.lumen.inspector.protocol.module.DatabaseDescriptor;
import dev.lumen.inspector.protocol.module.DatabaseDriver2;

import java.util.ArrayList;
import java.util.List;

/**
 * @deprecated Use {@link DatabaseDriver2} directly.  This is provided only for legacy
 * drivers to be adapted internally within Lumen.
 */
@Deprecated
public class DatabaseDriver2Adapter
    extends DatabaseDriver2<DatabaseDriver2Adapter.StringDatabaseDescriptor> {
  private final Database.DatabaseDriver mLegacy;

  public DatabaseDriver2Adapter(Database.DatabaseDriver legacy) {
    super(legacy.getContext());
    mLegacy = legacy;
  }

  @Override
  public List<StringDatabaseDescriptor> getDatabaseNames() {
    List<?> names = mLegacy.getDatabaseNames();
    List<StringDatabaseDescriptor> descriptors = new ArrayList<>(names.size());
    for (Object name : names) {
      descriptors.add(new StringDatabaseDescriptor(name.toString()));
    }
    return descriptors;
  }

  @SuppressWarnings("unchecked")
  public List<String> getTableNames(StringDatabaseDescriptor database) {
    return mLegacy.getTableNames(database.name);
  }

  @SuppressWarnings("unchecked")
  public Database.ExecuteSQLResponse executeSQL(
      StringDatabaseDescriptor database,
      String query,
      ExecuteResultHandler handler) throws SQLiteException {
    return mLegacy.executeSQL(database.name, query, handler);
  }

  static class StringDatabaseDescriptor implements DatabaseDescriptor {
    public final String name;

    public StringDatabaseDescriptor(String name) {
      this.name = name;
    }

    @Override
    public String name() {
      return name;
    }
  }
}
