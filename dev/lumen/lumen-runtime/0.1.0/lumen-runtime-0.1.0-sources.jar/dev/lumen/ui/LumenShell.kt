package dev.lumen.ui

import dev.lumen.LumenAgent
import dev.lumen.store.LogSegmentInfo

/**
 * Shared log-segment commands for the in-app picker and
 * `adb shell content call … lumen-init`.
 */
object LumenShell {

  fun resolveSegmentId(raw: String?): String? {
    val id = raw?.trim().orEmpty()
    return if (id.isEmpty() || id.equals("live", true) || id.equals("latest", true) || id == "null") {
      null
    } else {
      id
    }
  }

  fun setActiveSegment(raw: String?): String {
    val store = LumenAgent.store ?: return "error: LumenAgent not started"
    val id = resolveSegmentId(raw)
    if (id != null && store.logs.listSegments().none { it.id == id }) {
      return "error: unknown segment $id"
    }
    store.logs.setActiveSegment(id)
    return "ok active=${id ?: "live"}"
  }

  fun listText(): String {
    val store = LumenAgent.store ?: return "error: LumenAgent not started"
    val active = store.logs.activeSegmentId
    val lines = ArrayList<String>()
    lines.add("active=${active ?: "live"}")
    lines.add(formatLive(active == null))
    for (seg in store.logs.listSegments()) {
      lines.add(formatSeg(seg, seg.id == active))
    }
    return lines.joinToString("\n")
  }

  fun formatLive(selected: Boolean): String {
    val mark = if (selected) "*" else " "
    return "$mark live  |  current logcat page (Chrome Console window)"
  }

  fun formatSeg(seg: LogSegmentInfo, selected: Boolean): String {
    val mark = if (selected) "*" else " "
    return "$mark ${seg.id}  |  ${seg.lineCount} lines  |  ${seg.sizeBytes} B  |  ${seg.fileName}"
  }

  fun dumpAccess(): String = dev.lumen.server.AccessLog.dump()

  /** In-memory network snapshot, including archived WebSocket frames. */
  fun dumpNetwork(): String {
    val store = LumenAgent.store ?: return "error: LumenAgent not started"
    val records = store.network.allRecords()
    val lines = ArrayList<String>()
    lines.add("networkCount=${records.size}")
    for (rec in records) {
      if (!rec.isWebSocket && !rec.resourceType.equals("WebSocket", ignoreCase = true)) {
        continue
      }
      lines.add(
        "WS id=${rec.requestId} status=${rec.statusCode} frames=${rec.wsFrames.size}/${rec.wsFrameCount} url=${rec.url}",
      )
      for ((i, frame) in rec.wsFrames.withIndex()) {
        if (i >= 40 && i < rec.wsFrames.size - 5) {
          if (i == 40) lines.add("  … ${rec.wsFrames.size - 45} omitted …")
          continue
        }
        val preview = if (frame.payload.length > 80) frame.payload.substring(0, 80) + "…" else frame.payload
        val dir = if (frame.outgoing) "send" else "recv"
        lines.add("  #$i $dir op=${frame.opcode} ${preview.replace('\n', ' ')}")
      }
    }
    return lines.joinToString("\n")
  }
}
