package dev.lumen.server

import java.util.ArrayDeque

/** Last HTTP/CDP paths Chrome hit. Query via `content call … dumpAccess` — not logcat. */
object AccessLog {
  private const val MAX = 40
  private val lines = ArrayDeque<String>()

  @JvmStatic
  fun record(line: String) {
    synchronized(lines) {
      lines.addLast("${System.currentTimeMillis()} $line")
      while (lines.size > MAX) lines.removeFirst()
    }
  }

  @JvmStatic
  fun dump(): String = synchronized(lines) {
    if (lines.isEmpty()) "(empty)" else lines.joinToString("\n", postfix = "\n")
  }
}
