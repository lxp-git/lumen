package dev.lumen.init

import android.content.Context
import dev.lumen.inspector.DeferredEndpoint
import dev.lumen.inspector.DevtoolsSocketHandler
import dev.lumen.server.AddressNameHelper
import dev.lumen.server.LocalSocketServer
import dev.lumen.server.ProtocolDetectingSocketHandler
import java.io.IOException

/**
 * Binds `@lumen_*_devtools_remote` before [LumenAgent] class-loads.
 * Chrome inspect Reconnect is a 1s HttpUpgrade; waiting for EventStore / DOM
 * modules missed that window (measured 1.3s after pid).
 */
object DevtoolsEarlyBind {
  @Volatile
  private var endpoint: DeferredEndpoint? = null

  @JvmStatic
  @Synchronized
  fun bind(context: Context): DeferredEndpoint {
    endpoint?.let { return it }
    val deferred = DeferredEndpoint()
    val devtools = DevtoolsSocketHandler(context.applicationContext, deferred)
    val socketHandler = ProtocolDetectingSocketHandler(context.applicationContext)
    socketHandler.addHandler(
      ProtocolDetectingSocketHandler.AlwaysMatchMatcher(),
      devtools,
    )
    try {
      LoopbackCdpServer.start(devtools)
    } catch (_: IOException) {
    }
    // Internal name: the out-of-process proxy connects here. Chrome still
    // discovers `*_devtools_remote`.
    startServer("lumen-cdp", AddressNameHelper.createCustomAddress("_cdp"), socketHandler)
    try {
      LocalSocketServer(
        "lumen",
        AddressNameHelper.createCustomAddress("_devtools_remote"),
        socketHandler,
      ).bindAndStartAccepting(false)
    } catch (_: IOException) {
      // Proxy already owns the Chrome-facing name. That is the intended setup.
    }
    endpoint = deferred
    return deferred
  }

  @JvmStatic
  fun get(): DeferredEndpoint? = endpoint

  private fun startServer(
    name: String,
    address: String,
    socketHandler: ProtocolDetectingSocketHandler,
  ) {
    LocalSocketServer(name, address, socketHandler).bindAndStartAccepting()
  }
}
