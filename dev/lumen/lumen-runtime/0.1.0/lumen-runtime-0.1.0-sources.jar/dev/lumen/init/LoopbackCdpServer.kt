package dev.lumen.init

import dev.lumen.inspector.DevtoolsSocketHandler
import dev.lumen.server.LeakyBufferedInputStream
import dev.lumen.server.SocketLike
import java.net.InetAddress
import java.net.ServerSocket

/**
 * Loopback HTTP+WS so the out-of-process proxy (root/shell) can reach CDP.
 * Abstract Unix sockets created by the app are SELinux-blocked from shell.
 */
internal object LoopbackCdpServer {
  const val PORT = 18789

  fun start(handler: DevtoolsSocketHandler) {
    val server = ServerSocket(PORT, 8, InetAddress.getByName("127.0.0.1"))
    Thread({
      while (!server.isClosed) {
        val socket = try {
          server.accept()
        } catch (_: Exception) {
          break
        }
        Thread({
          try {
            val leaky = LeakyBufferedInputStream(socket.getInputStream(), 1024)
            handler.onAccepted(SocketLike(socket.getOutputStream(), leaky))
          } catch (_: Exception) {
          } finally {
            try {
              socket.close()
            } catch (_: Exception) {
            }
          }
        }, "lumen-cdp-tcp").apply { isDaemon = true; start() }
      }
    }, "lumen-cdp-listen").apply { isDaemon = true; start() }
  }
}
